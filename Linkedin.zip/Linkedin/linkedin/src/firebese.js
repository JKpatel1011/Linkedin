import { initializeApp } from "firebase/app";
import { getAuth, GoogleAuthProvider } from "firebase/auth";
import firebase from "firebase/compat/app";
import { getFirestore } from "firebase/firestore";
import { getStorage } from "firebase/storage";


// For Firebase JS SDK v7.20.0 and later, measurementId is optional
const firebaseConfig = {
    apiKey: "AIzaSyDXkOmibY4ULnOcLzVBHNQ-e8rkoZMHWSY",
    authDomain: "linkedin-demo-ec67d.firebaseapp.com",
    projectId: "linkedin-demo-ec67d",
    storageBucket: "linkedin-demo-ec67d.appspot.com",
    messagingSenderId: "76489967585",
    appId: "1:76489967585:web:00b0f99b826e412ca2b4a0",
    measurementId: "G-F3LCJKVXXK"
  }; 

  if (!firebase.apps.length) {
    firebase.initializeApp(firebaseConfig);
  }
  const app = initializeApp(firebaseConfig);
  const auth = getAuth(app);
  const db = getFirestore(app);
  const provider = new GoogleAuthProvider();
  const storage = getStorage();

  export{ auth,provider,storage} ;
  export  default db;