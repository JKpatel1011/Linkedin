import React, { useState } from 'react'
import { FaImage } from "react-icons/fa";
import { FaYoutube } from "react-icons/fa";
import { useDispatch, useSelector } from 'react-redux';
import styled from 'styled-components';
import { addAction } from '../Redux1/Action';
import axios from 'axios';

export default function Model({ setShaow, shaow }) {

    let dispatch = useDispatch()
    const [itam, setItam] = useState({
        text: "",
        video: "",


    })


    console.log(itam)
    let box = useSelector(store => store.data)



    const handleFileChange = (event) => {
        const file = event.target.files[0];
        if (file) {
            const reader = new FileReader();
            reader.onloadend = () => {
                

                dispatch(addAction(reader.result))
            };
            reader.readAsDataURL(file);
        }
    };
    const user = useSelector((state) => state.auth.user);

    async function Post() {


        dispatch(addAction(itam))
        try {
            const respons = await axios.post("http://localhost:3000/data",{ box: itam })
            // setTodo([...todo,respons.data])
            console.log(respons.data)
        } catch (error) {
            console.log(error)

        }




    }
    return (
        <div>
            <div class="modal fade" id="exampleModal" tabindex="-1" aria-labelledby="exampleModalLabel" aria-hidden="true">
                <div class="modal-dialog">
                    <div class="modal-content">
                        <div class="modal-header">
                            <h5 class="modal-title" id="exampleModalLabel">Create a post</h5>
                            <button type="button" class="btn-close" data-bs-dismiss="modal" aria-label="Close"></button>
                        </div>
                        <div class="modal-body">
                            <div className="box1 d-flex gap-3 align-items-center " style={{ height: "auto" }}>
                                <img style={{ borderRadius: "50%", width: "50px" }} src={user.photoURL} alt="" /> <span>{user.displayName}</span>
                            </div>
                            <center>



                            </center>

                            <center>


                                {
                                    shaow ? (<UploadImage className='mt-5'>
                                        <input
                                            type="file"
                                            name="image"

                                            id="file"
                                            style={{ display: "none" }}
                                            onChange={handleFileChange}
                                            data-bs-dismiss="modal"
                                        />
                                        <p>
                                            <label
                                                style={{
                                                    cursor: "pointer",
                                                    display: "block",
                                                    marginBottom: "15px",
                                                }}
                                                htmlFor="file"
                                            >
                                                Select an image to share
                                            </label>
                                        </p>

                                    </UploadImage>)
                                        : (
                                            <div>

                                                <textarea className='mt-4'
                                                    style={{ width: "90%" }}
                                                    value={itam.text}
                                                    onChange={(e) => setItam({
                                                        ...itam, text: e.target.value
                                                    })}
                                                    placeholder="What do you want to talk about?"

                                                />

                                                <input
                                                    style={{ width: "90%", height: "30px" }}
                                                    type="text"
                                                    value={itam.video}
                                                    onChange={(e) => setItam({
                                                        ...itam, video: e.target.value
                                                    })}
                                                    placeholder="Please input a video link"
                                                />
                                            </div>)
                                }

                                {/* <input type="file" onChange={handleFileChange} style={{width:"90%",border:"none"}} /> */}


                            </center>
                            {/* {image && <img src={image} alt="Uploaded" style={{ maxWidth: '100%' }} />} */}

                        </div>
                        <div class="modal-footer d-flex justify-content-between ">

                            <div className="box d-flex gap-2">
                                <button className='fs-4 ' onClick={() => setShaow(true)}><FaImage /></button>
                                <br />
                                <button className="fs-3" onClick={() => setShaow(false)}><FaYoutube /></button>

                            </div>

                            <div className="post btn btn-primary " data-bs-dismiss="modal" onClick={Post}>
                                Post
                            </div>

                        </div>

                    </div>
                </div>
            </div>
        </div>
    )
}

const UploadImage = styled.div`
  text-align: center;
  img {
    width: 100%;
  }
  `;
