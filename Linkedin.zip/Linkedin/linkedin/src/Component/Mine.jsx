import React, { useState } from 'react'
import { useSelector } from 'react-redux';
import styled from 'styled-components'
import Model from './Model';

// export const AddPost = '';


export default function Mine() {
  const [counnter, setCounnter] = useState(0)
  const [coummet, setcoummet] = useState(0)
  
  const [shaow, setShaow] = useState(false)




  function inriment() {
    setCounnter(counnter + 1)
  }

  const user = useSelector((state) => state.auth.user);
console.log(user)
  let box = useSelector(store => store.data)


  

  console.log(box)

  return (
    <Container>
      <ShareBox>
        <div>
          {
            user.photoURL ? <img src={user.photoURL} alt={"no pic"} /> : <img src={"/images/user.svg"} alt='no pic' />

          }

          <button data-bs-toggle="modal" data-bs-target="#exampleModal">
            Start a post
          </button>
        </div>
        <div>
          <button data-bs-toggle="modal" data-bs-target="#exampleModal" onClick={() => setShaow(true)} className='p-2'>
            <img src="/images/photo-icon.svg" alt="" />
            <span   data-bs-target="#exampleModal">Photo</span>
          </button>
          <button onClick={() => setShaow(false)} data-bs-toggle="modal" data-bs-target="#exampleModal" className='p-2'>
            <img src="/images/video-icon.svg" alt="" />
            <span  >Video</span>
          </button>
          <button className='p-2'>
            <img src="/images/event-icon.svg" alt="" />
            <span>Event</span>
          </button>
          <button className='p-2'>
            <img src="/images/article-icon.svg" alt="" />
            <span>Write article</span>
          </button>
        </div>
      </ShareBox>
      <Content>

        {
          box.map((x) => {
            return <Article >

              <SharedActor>
                <a href='##'>
                  <img src={user.photoURL} alt='no pic' />
                  <div>
                    <span>{user.displayName}</span>

                  </div>
                </a>
                <button>
                  <img src="/images/ellipsis.svg" alt=" no pic" />
                </button>
              </SharedActor>
              <Description className=''>{x.text}</Description>
              <SharedImg>

                {
                  x.video?  
             <center><video style={{width:"100%"}} controls autoPlay loop src={x.video}></video></center>:<img src={x.img} alt="" />
            }
            
            {/* <iframe width="99%" height="315" src={x.video} title="YouTube video player" frameborder="0" allow="accelerometer; autoplay; clipboard-write; encrypted-media; gyroscope; picture-in-picture; web-share" referrerpolicy="strict-origin-when-cross-origin" allowfullscreen></iframe> */}
              </SharedImg>
              <SocialCounts>
                <li>
                  <button>
                    <img
                      src="https://static-exp1.licdn.com/sc/h/2uxqgankkcxm505qn812vqyss"
                      alt=""
                    />
                    <img
                      src="https://static-exp1.licdn.com/sc/h/f58e354mjsjpdd67eq51cuh49"
                      alt=""
                    />
                    <span> Like{counnter}</span>
                  </button>
                </li>
                <li>
                  <a href='##'> Comment {coummet}</a>
                </li>
                <li>
                  <a href='##'>1 share</a>
                </li>
              </SocialCounts>
              <SocialActions>
                <button onClick={inriment}>
                  <img src="/images/like-icon.svg" alt="" />
                  <span>Like</span>
                </button>
                <button onClick={() => setcoummet(coummet + 1)}>
                  <img src="/images/comment-icon.svg" alt="" />
                  <span>Comment</span>
                </button>
                <button>
                  <img src="/images/share-icon.svg" alt="" />
                  <span>Share</span>
                </button>
                <button>
                  <img src="/images/send-icon.svg" alt="" />
                  <span>Send</span>
                </button>
              </SocialActions>
            </Article>
          })
        }


      </Content>
      {/* <!-- Modal --> */}
      {/* <div class="modal fade" id="exampleModal" tabindex="-1" aria-labelledby="exampleModalLabel" aria-hidden="true">
        <div class="modal-dialog">
          <div class="modal-content">
            <div class="modal-header">
              <h5 class="modal-title" id="exampleModalLabel">Create a post</h5>
              <button type="button" class="btn-close" data-bs-dismiss="modal" aria-label="Close"></button>
            </div>
            <div class="modal-body">
              <div className="box1 d-flex gap-3 align-items-center " style={{ height: "auto" }}>
                <img style={{ borderRadius: "50%", width: "50px" }} src={user.photoURL} alt="" /> <span>{user.displayName}</span>
              </div>
              <center>


                <textarea className='mt-4'
                  style={{ width: "90%" }}

                 onChange={(e) => setEditorText(e.target.value)}
                  placeholder="What do you want to talk about?"

                />
              </center>

              <center>


                {
                  shaow ? (<UploadImage className='mt-5'>
                    <input
                      type="file"
                      name="image"
                      id="file"
                      style={{ display: "none" }}
                      onChange={handleFileChange}
                    />
                    <p>
                      <label
                        style={{
                          cursor: "pointer",
                          display: "block",
                          marginBottom: "15px",
                        }}
                        htmlFor="file"
                      >
                        Select an image to share
                      </label>
                    </p>
                    {image && (
                      <img src={image} alt="img" />
                    )}
                  </UploadImage>)
                    : (<input
                      style={{ width: "90%", height: "30px" }}
                      type="text"
                      
                      onChange={(e) => setVideo(e.target.value) }
                      placeholder="Please input a video link"
                    />)
                }



              </center>

            </div>
            <div class="modal-footer d-flex justify-content-between ">

              <div className="box d-flex gap-2">
                <button className='fs-4 ' onClick={() => setShaow(true)}><FaImage /></button>
                <br />
                <button className="fs-3" onClick={() => setShaow(false)}><FaYoutube /></button>

              </div>

              <div className="post btn btn-primary " data-bs-dismiss="modal"  onClick={Post}>
                Post
              </div>

            </div>

          </div>
        </div>
      </div> */}

      <Model shaow={shaow} setShaow={setShaow} />
    </Container>

  )
}
const Container = styled.div`
  grid-area: main;
`;
const CommonCard = styled.div`
  text-align: center;
  overflow: hidden;
  margin-bottom: 8px;
  background-color: #fff;
  border-radius: 5px;
  position: relative;
  box-shadow: 0 0 0 1px rgb(0 0 0 / 15%), 0 0 1px rgb(0 0 0 / 20%);
`;

const ShareBox = styled(CommonCard)`
  display: flex;
  flex-direction: column;
  color: #958b7b;
  margin: 0 0 8px;
  background: white;
  div {
    button {
      outline: none;
      color: rgba(0, 0, 0.6);
      font-size: 14px;
      line-height: 1.5;
      min-height: 48px;
      background: transparent;
      border: none;
      display: flex;
      align-items: center;
      font-weight: 500;
      cursor: pointer;
      transition: background 0.3s ease;
      border-radius: 5px;
      &:hover {
        background: rgba(0, 0, 0, 0.08);
      }
    }
    &:first-child {
      display: flex;
      align-items: center;
      padding: 8px 16px 8px 16px;
      img {
        width: 48px;
        border-radius: 50%;
        margin-right: 8px;
      }
      button {
        margin: 4px 0;
        flex-grow: 1;
        border-radius: 35px;
        padding-left: 16px;
        border: 1px solid rgba(0, 0, 0, 0.15);
        background: white;
        color: rgba(0, 0, 0, 0.7);
        font-weight: 500;
        font-size: 14px;
        &:hover {
          background: rgba(0, 0, 0, 0.08);
        }
        text-align: left;
      }
    }
    &:nth-child(2) {
      display: flex;
      flex-wrap: wrap;
      justify-content: space-around;
      padding-bottom: 4px;
      button {
        img {
          margin: 0 4px;
        }
        span {
          color: #70b5f9;
          margin-top: 2px;
        }
      }
    }
  }
`;
const Content = styled.div`
  text-align: center;
  & > img {
    width: 70px;
  }
`;
const Article = styled(CommonCard)`
  padding: 0;
  margin: 0 0 8px;
  overflow: visible;
`;
const SharedActor = styled.div`
  flex-wrap: nowrap;
  padding: 12px 16px 0;
  margin-bottom: 8px;
  align-items: center;
  display: flex;
  a {
    margin-right: 12px;
    flex-grow: 1;
    overflow: hidden;
    display: flex;
    text-decoration: none;

    img {
      width: 48px;
      height: 48px;
      border-radius: 50%;
    }
    & > div {
      display: flex;
      flex-direction: column;
      flex-grow: 1;
      flex-basis: 0;
      margin-left: 8px;
      overflow: hidden;
      span {
        text-align: left;
        &:first-child {
          font-size: 14px;
          font-weight: 700;
          color: rgba(0, 0, 0, 1);
        }
        &:nth-child(2),
        &:nth-child(3) {
          font-size: 12px;
          color: rgba(0, 0, 0, 0.6);
        }
      }
    }
  }
  button {
    position: absolute;
    right: 12px;
    top: 0;
    background: transparent;
    border: none;
    ouline: none;
  }
`;
const Description = styled.div`
  padding: 0 16px;
  overflow: hidden;
  color: rgba(0, 0, 0, 0.9);
  font-size: 14px;
  text-align: left;
`;
const SharedImg = styled.div`
  margin-top: 8px;
  width: 100%;
  diplay: block;
  position: relative;
  background-color: #f9fafb;
  img {
    object-fit: contain;
    width: 100%;
    height: 100%;
  }
`;
const SocialCounts = styled.ul`
  line-height: 1.3;
  display: flex;
  align-items: center;
  overflow: auto;
  margin: 0 16px;
  padding: 8px 0;
  border-bottom: 1px solid #e9e5df;
  list-style: none;
  li {
    margin-right: 5px;
    font-size: 12px;
    button {
      display: flex;
      align-items: center;
      border: none;
      background-color: white;
    }
  }
`;
const SocialActions = styled.div`
  display: flex;
  align-items: center;
  justify-content: flex-start;
  max-width: 100%;
  flex-wrap: wrap;
  margin: 0;
  min-height: 40px;
  padding: 4px 8px;
  button {
    display: inline-flex;
    align-items: center;
    padding: 8px;
    color: rgba(0, 0, 0, 0.6);
    border: none;
    background-color: white;
    cursor: pointer;
    border-radius: 5px;
    transition: background 0.3s;
    width: calc(100% / 4);
    height: 60px;
    justify-content: center;

    &:hover {
      background: rgba(0, 0, 0, 0.08);
    }
    @media (min-width: 768px) {
      span {
        margin-left: 8px;
        margin-top: 3px;
        font-weight: 600;
      }
    }
  }
`;

