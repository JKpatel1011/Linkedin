import React, { useEffect, useState } from 'react'
// import  signAPI  from '../Action/Googel'
import  {login}  from '../Action/Googel'
import { useDispatch, useSelector } from 'react-redux';
import { useNavigate } from 'react-router-dom';
// import {auth,provider} from "../firebese"
// import { signInWithPopup } from 'firebase/auth'
// import { useDispatch } from 'react-redux';
// import { useNavigate } from 'react-router-dom';
// import { addAction } from '../Redux/Action';
 

function Login() {
// // let dipach = useDispatch()
// const [data, setdata] = useState(
   const dispatch = useDispatch();
// )


const user = useSelector((state) => state.auth.user);
let neviget = useNavigate()
  useEffect(() => {
   if(user){
    neviget("/home")
   }else{
      neviget("/")
   }
  }, [user])
console.log(user)

   
   return (
      <div className='container-fuild box  bg-light  '>
         <nav className="nav d-flex justify-content-center   ">
            <div className=" col-sm-6   col-md-6 mt-3    ">

               <img src="/images/login-logo.svg" alt="" className='mx-5 mt-3 ' style={{ width: "135px", height: "34px" }} />
            </div>
            <div className=" col-sm-6 col-md-6 gap-3 mt-4  d-flex ">
               <button className='join col-sm-2 ms-5 col-md-3 mt-2  btn btn-outline-secondary'>Join now</button>
               <button className='Sing col-sm-2 ms-5 col-md-3 rounded-pill  mt-2 btn btn-outline-primary'>Sign in</button>
            </div>
         </nav>
         <div className="nav d-flex justify-content-center mt-5 ">
            <div className=" col-12 col-sm-6 col-md-6 mt-4  ">
               <h1 className='h1 mx-5'>Welcome to your professional community</h1>
               <center>
                  <button className='button rounded-pill p-3 gap-2 d-flex mt-5 align-items-center' onClick={()=>dispatch(login())} style={{ height: "auto" }}>
                     <img className='mt-1' src="/images/google.svg" alt="" />
                     <p className=''>Sign in with Google</p>
                  </button>
               </center>
            </div>
            <div className=" col-12 col-sm-6 col-md-6 gap-3 mt-4    d-flex ">
               <img className='img-fluid' src="http://localhost:3000/images/login-hero.svg" alt="" />
            </div>
         </div>

      </div>
   )
}





export default Login


