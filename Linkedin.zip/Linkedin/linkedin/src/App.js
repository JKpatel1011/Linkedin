import './App.css';
import { BrowserRouter as Router, Routes, Route } from "react-router-dom";
import Login from './Component/Login';
import Home from './Home';
import Header from './Component/Header';
import { useState } from 'react';
import ImageUpload from './expariment';
// import signAPI from './Action/Googel';


function App() {
  //  const dispatch = useDispatch()



  return (
    <Router>
       
    
      
      
      <Routes>
       
        <Route path='/' element={<Login/>} />
        <Route path='/Home' element={
        <div>
            <Header />
            <Home />
            
            
        </div>
        
        
          
      } />
      <Route path='/img' element={<ImageUpload/>}/>
    
      </Routes>

    </Router>
  );
}

export default App;
