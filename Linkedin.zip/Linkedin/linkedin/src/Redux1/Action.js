export const addAction = (paylod) => {
    return{
        type:"ADD",
        paylod
    }
}