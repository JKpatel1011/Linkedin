let arr = []

export const reducer = (state = arr, action) => {
    if (action.type === "ADD") {

        return state =[...state,{text:action.paylod.text,video:action.paylod.video,img:action.paylod,}]

    }
    return state

}
