import React, { useState } from 'react';

const ImageUpload = () => {
    const [image, setImage] = useState(null);

    const handleFileChange = (event) => {
        const file = event.target.files[0];
        if (file) {
            const reader = new FileReader();
            reader.onloadend = () => {
                setImage(reader.result);
            };
            reader.readAsDataURL(file);
        }
    };

    return (
        <div>
            <h1>Upload an Image</h1>
            <input type="file" accept="image/*" onChange={handleFileChange} />
            {image && <img src={image} alt="Uploaded" style={{ maxWidth: '100%' }} />}
        </div>
    );
};

export default ImageUpload;
