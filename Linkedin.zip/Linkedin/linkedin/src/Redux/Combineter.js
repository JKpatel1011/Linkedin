import { combineReducers } from 'redux';
import authReducer from './Reducer';
import { reducer } from '../Redux1/Reduser';

const rootReducer = combineReducers({
  auth: authReducer,
  data:reducer
});

export default rootReducer;
