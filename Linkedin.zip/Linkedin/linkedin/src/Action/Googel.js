import { useNavigate } from 'react-router-dom';
import { auth, provider } from '../firebese';
import { signInWithPopup, signOut } from 'firebase/auth';
// signInWithPopup

export const LOGIN_SUCCESS = 'LOGIN_SUCCESS';
export const LOGOUT_SUCCESS = 'LOGOUT_SUCCESS';

export const login = () => async (dispatch) => {
  try {
    const result = await signInWithPopup( auth,provider);
    dispatch({ type: LOGIN_SUCCESS, payload: result.user });
  } catch (error) {
    console.error("Login error", error);
  }
};

// const naviget = useNavigate()
export const logout = () => async (dispatch) => {
  try {
    await signOut(auth);
    dispatch({ type: LOGOUT_SUCCESS });
    // naviget("/")
    
  } catch (error) {
    console.error("Logout error", error);
  }
};
